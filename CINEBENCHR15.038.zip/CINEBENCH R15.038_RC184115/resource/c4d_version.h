#define C4D_V1		15
#define C4D_V2		0
#define C4D_V3		3
#define C4D_V4		8

#define CYEAR		"2016"
