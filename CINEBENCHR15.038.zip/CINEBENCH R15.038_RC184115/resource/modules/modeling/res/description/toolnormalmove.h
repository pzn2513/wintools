#ifndef TOOLNORMALMOVE_H__
#define TOOLNORMALMOVE_H__

enum
{
	MDATA_NORMALMOVE_VALUE				= 1100,   // Real

	MDATA_NORMALMOVE_
};

#endif	// TOOLNORMALMOVE_H__
