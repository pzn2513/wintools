#ifndef TOOLMOVE_H__
#define TOOLMOVE_H__

#include "toolmodelingaxis.h"

enum
{
	MDATA_MODELING_MOVE_
};

#endif	// TOOLMOVE_H__
