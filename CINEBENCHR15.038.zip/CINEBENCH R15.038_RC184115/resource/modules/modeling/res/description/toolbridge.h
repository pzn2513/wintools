#ifndef TOOLBRIDGE_H__
#define TOOLBRIDGE_H__

enum
{

	MDATA_BRIDGE_ELEMENT1                    =1100, //LONG
	MDATA_BRIDGE_ELEMENT2                    =1101, //LONG
	MDATA_BRIDGE_ELEMENT3                    =1102, //LONG
	MDATA_BRIDGE_ELEMENT4                    =1103, //LONG
	MDATA_BRIDGE_OBJINDEX1                   =1104, //LONG
	MDATA_BRIDGE_OBJINDEX2                   =1105, //LONG
	MDATA_BRIDGE_OBJINDEX3                   =1106, //LONG
	MDATA_BRIDGE_OBJINDEX4                   =1107, //LONG
	MDATA_BRIDGE_DELETE                      =1108, //BOOL
	MDATA_BRIDGE_ISO		                     =1109, //BOOL
	MDATA_BRIDGE_
};

#endif	// TOOLBRIDGE_H__
