#ifndef TOOLBASE_H__
#define TOOLBASE_H__

enum
{
	// start with 700 because Obase starts at 900
	MDATA_MAINGROUP 								= 700,
	MDATA_NEWTRANSFORM							= 701,   // Button
	MDATA_DEFAULTVALUES							= 702,   // Button
	MDATA_COMMANDGROUP							= 703,
	MDATA_APPLY											= 704,
	MDATA_INTERACTIVE								= 705,
	MDATA_TEMPINTERACTIVE						= 706,		// temp
	ID_SNAPSETTINGS									= 999999,
	MDATA_
};

#endif	// TOOLBASE_H__
