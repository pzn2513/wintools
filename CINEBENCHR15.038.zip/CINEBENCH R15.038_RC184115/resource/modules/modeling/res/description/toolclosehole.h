#ifndef TOOLCLOSEHOLE_H__
#define TOOLCLOSEHOLE_H__

enum
{
	MDATA_CLOSEHOLE_EDGE											=1100, //LONG
	MDATA_CLOSEHOLE_POLYGON                   =1101, //LONG
	MDATA_CLOSEHOLE_INDEX                     =1102, //LONG
	MDATA_CLOSEHOLE_TRI		                    =1103, //LONG
	MDATA_CLOSEHOLE_
};

#endif	// TOOLCLOSEHOLE_H__
