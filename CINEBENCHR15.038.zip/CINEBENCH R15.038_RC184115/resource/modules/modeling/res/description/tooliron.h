#ifndef TOOLIRON_H__
#define TOOLIRON_H__

enum
{
	MDATA_IRON_ANGLE   													=1100, //REAL
	MDATA_IRON_PERCENT   												=1101, //REAL
	MDATA_IRON_
};

#endif	// TOOLIRON_H__
