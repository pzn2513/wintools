#ifndef TOOLRECTSELECTION_H__
#define TOOLRECTSELECTION_H__

#include "toolmodelingaxis.h"

enum
{
	MDATA_SELECTRECT_
};

#endif	// TOOLRECTSELECTION_H__
