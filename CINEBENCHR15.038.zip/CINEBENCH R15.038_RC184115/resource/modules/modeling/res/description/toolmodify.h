#ifndef TOOLMODIFY_H__
#define TOOLMODIFY_H__

enum
{
	MDATA_TOOLMODIFY_
};

#endif	// TOOLMODIFY_H__
