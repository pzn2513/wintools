#ifndef FEDIT_H__
#define FEDIT_H__

enum
{
	ID_FILTEREMULATION 		= 1000,
	FILTEREMULATION_EDIT 	= 1001
};

#endif	// FEDIT_H__

