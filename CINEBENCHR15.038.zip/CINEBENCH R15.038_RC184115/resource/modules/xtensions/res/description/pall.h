#ifndef PALL_H__
#define PALL_H__

enum
{
		PALL_TEST = 1000,
		PALL_
};

#endif	// PALL_H__
