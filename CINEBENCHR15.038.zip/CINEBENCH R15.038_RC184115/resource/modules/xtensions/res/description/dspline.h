#ifndef DSPLINE_H__
#define DSPLINE_H__

enum
{
	SPLINESUBCHANNEL_TENSION	= 1000 // real
};

#endif	// DSPLINE_H__
