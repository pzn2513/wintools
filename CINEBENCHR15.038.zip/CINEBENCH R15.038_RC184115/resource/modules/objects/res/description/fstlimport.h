#ifndef FSTLIMPORT_H__
#define FSTLIMPORT_H__

enum
{
	STLIMPORTFILTER_GROUP						= 999,
	STLIMPORTFILTER_SCALE		 				= 2000
};

#endif	// FSTLIMPORT_H__
