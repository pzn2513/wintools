#ifndef TALIGNTOPATH_H__
#define TALIGNTOPATH_H__

enum
{
	ALIGNTOPATHTAG_LOOKAHEAD		= 1000
};

#endif	// TALIGNTOPATH_H__
