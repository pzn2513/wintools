#ifndef OPYRAMID_H__
#define OPYRAMID_H__

enum
{
	PRIM_PYRAMID_LEN					= 1220, // VECTOR   - Pyramid Size [>=0.0]
	PRIM_PYRAMID_SUB					= 1221 // LONG     - Segments [>0]
};

#endif	// OPYRAMID_H__
