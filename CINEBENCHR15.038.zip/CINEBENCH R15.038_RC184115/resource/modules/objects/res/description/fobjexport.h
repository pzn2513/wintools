#ifndef FOBJEXPORT_H__
#define FOBJEXPORT_H__

enum
{
	OBJEXPORTFILTER_GROUP						= 999,
	OBJEXPORTFILTER_SCALE		 				= 2000
};

#endif	// FOBJEXPORT_H__
