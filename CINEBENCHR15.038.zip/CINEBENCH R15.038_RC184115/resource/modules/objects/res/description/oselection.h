#ifndef OSELECTION_H__
#define OSELECTION_H__

enum
{
	SELECTIONOBJECT_LIST			= 1000,
	SELECTIONOBJECT_RESTORE		= 1001 // virtual ID
};

#endif	// OSELECTION_H__
