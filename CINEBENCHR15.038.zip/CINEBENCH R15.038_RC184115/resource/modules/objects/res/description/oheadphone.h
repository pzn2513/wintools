#ifndef OHEADPHONE_H__
#define OHEADPHONE_H__

enum
{
	HEADPHONEOBJECT_BASIS							= 1000
};

#endif	// OHEADPHONE_H__
