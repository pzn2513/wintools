#ifndef OFIGURE_H__
#define OFIGURE_H__

enum
{
	PRIM_FIGURE_HEIGHT				= 1210, // REAL     - Height [>=0.0]
	PRIM_FIGURE_SUB						= 1211 // LONG     - Subdivision [>2]
};

#endif	// OFIGURE_H__
