#ifndef DBLEND_H__
#define DBLEND_H__

enum
{
	blend_data_dummy
};

#endif	// DBLEND_H__
