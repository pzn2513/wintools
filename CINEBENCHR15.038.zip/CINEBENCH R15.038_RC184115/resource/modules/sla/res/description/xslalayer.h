#ifndef XSLALAYER_H__
#define XSLALAYER_H__

enum
{
	XSLALayer                             = 1000,

	SLA_LAYER_BLEND                       = 1001
};

#endif	// XSLALAYER_H__
