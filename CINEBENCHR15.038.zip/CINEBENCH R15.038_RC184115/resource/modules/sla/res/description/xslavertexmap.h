#ifndef XSLAVERTEXMAP_H__
#define XSLAVERTEXMAP_H__

enum
{
	SLA_DIRTY_VMAP_OBJECT                 = 1001, // link
	SLA_DIRTY_VMAP_INVERT                 = 1002  // bool
};

#endif	// XSLAVERTEXMAP_H__
