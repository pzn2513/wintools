#ifndef XSLABUFFY_H__
#define XSLABUFFY_H__

enum
{
	XSLABuffy                             = 1000,

	SLA_BUFFY_COLOR_1                     = 1001, // vector
	SLA_BUFFY_COLOR_2                     = 1002  // vector
};

#endif	// XSLABUFFY_H__
