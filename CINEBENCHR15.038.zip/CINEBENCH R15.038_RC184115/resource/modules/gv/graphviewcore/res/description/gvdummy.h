#ifndef GVDUMMY_H__
#define GVDUMMY_H__

enum
{
	GV_DUMMY_
};

#endif	// GVDUMMY_H__
