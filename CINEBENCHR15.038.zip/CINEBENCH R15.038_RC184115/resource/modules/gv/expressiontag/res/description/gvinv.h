#ifndef GVINV_H__
#define GVINV_H__

#include "gvdynamic.h"

enum
{
	GV_INV_INPUT			= 2000,
	GV_INV_OUTPUT			= 3000,

	GV_INV_
};

#endif	// GVINV_H__
