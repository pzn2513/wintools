#ifndef GVRESULT_H__
#define GVRESULT_H__

#include "gvdynamic.h"

enum
{
	GV_RESULT_INPUT				= 2000,
	GV_RESULT_OUTPUT			= 3000,

	GV_RESULT_
};

#endif	// GVRESULT_H__
