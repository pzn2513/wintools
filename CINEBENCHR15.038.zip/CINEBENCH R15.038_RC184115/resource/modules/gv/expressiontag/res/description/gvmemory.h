#ifndef GVMEMORY_H__
#define GVMEMORY_H__

#include "gvdynamic.h"

enum
{
	GV_MEMORY_HISTORY_DEPTH		= 1000,

	GV_MEMORY_HISTORY_SWITCH	= 2000,
	GV_MEMORY_INPUT						= 2001,

	GV_MEMORY_OUTPUT					= 3000,

	GV_MEMORY_
};

#endif	// GVMEMORY_H__
