#ifndef GVCROSS_H__
#define GVCROSS_H__

#include "gvdynamic.h"

enum
{
	GV_CROSS_INPUT1	= 2000,
	GV_CROSS_INPUT2	= 2001,
	GV_CROSS_OUTPUT	= 3000,

	GV_CROSS_
};

#endif	// GVCROSS_H__
