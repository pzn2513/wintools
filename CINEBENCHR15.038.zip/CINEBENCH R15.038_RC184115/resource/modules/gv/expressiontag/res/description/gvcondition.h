#ifndef GVCONDITION_H__
#define GVCONDITION_H__

#include "gvdynamic.h"

enum
{
	GV_CONDITION_SWITCH		= 1000,
	GV_CONDITION_INPUT 		= 2000,
	GV_CONDITION_OUTPUT		= 3000
};

#endif	// GVCONDITION_H__
