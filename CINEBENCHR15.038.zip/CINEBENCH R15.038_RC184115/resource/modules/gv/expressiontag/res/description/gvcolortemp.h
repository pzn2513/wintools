#ifndef GVCOLORTEMP_H__
#define GVCOLORTEMP_H__

#include "gvbase.h"

enum
{
	GV_CTEMP_TEMPREATURE					 = 1001,
	GV_CTEMP_COLOR                 = 1002,

	GV_CTEMP_
};

#endif	// GVCOLORTEMP_H__
