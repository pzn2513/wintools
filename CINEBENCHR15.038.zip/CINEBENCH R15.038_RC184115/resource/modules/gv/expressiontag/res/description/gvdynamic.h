#ifndef GVDYNAMIC_H__
#define GVDYNAMIC_H__

enum
{
	GVdynamic 							= 200000000,
	GV_DYNAMIC_DATATYPE			= 200000001
};

#endif	// GVDYNAMIC_H__
