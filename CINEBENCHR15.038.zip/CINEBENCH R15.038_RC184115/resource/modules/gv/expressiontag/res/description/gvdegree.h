#ifndef GVDEGREE_H__
#define GVDEGREE_H__

#include "gvbase.h"

enum
{
	GV_DEGREE_FUNCTION_ID			= 1000,
		GV_RAD2DEGREE_NODE_FUNCTION = 0,
		GV_DEGREE2RAD_NODE_FUNCTION,

	GV_DEGREE_INPUT						= 2000,

	GV_DEGREE_OUTPUT					= 3000,

	GV_DEGREE_
};

#endif	// GVDEGREE_H__
