#ifndef GVADAPTER_H__
#define GVADAPTER_H__

#include "gvdynamic.h"

enum
{
	GV_ADAPTER_INPUT					= 2000,
	GV_ADAPTER_OUTPUT					= 3000,

	GV_ADAPTER_
};

#endif	// GVADAPTER_H__
