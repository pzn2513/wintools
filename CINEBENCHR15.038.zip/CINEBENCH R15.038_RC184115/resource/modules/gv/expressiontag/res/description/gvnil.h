#ifndef GVNIL_H__
#define GVNIL_H__

#include "gvdynamic.h"

enum
{
	GV_NIL_INPUT					= 2000,
	GV_NIL_OUTPUT					= 3000,

	GV_NIL_
};

#endif	// GVNIL_H__
