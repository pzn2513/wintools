#ifndef GVORDER_H__
#define GVORDER_H__

#include "gvdynamic.h"

enum
{
	GV_ORDER_INPUT1								= 2000,
	GV_ORDER_INPUT2								= 2001,
	GV_ORDER_OUTPUT								= 3000,

	GV_ORDER_
};

#endif	// GVORDER_H__
