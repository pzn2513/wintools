#ifndef GVMIX_H__
#define GVMIX_H__

#include "gvdynamic.h"

enum
{
	GV_MIX_INPUT_MIXINGFACTOR		= 2000,
	GV_MIX_INPUT1								= 2001,
	GV_MIX_INPUT2								= 2002,

	GV_MIX_OUTPUT								= 3000,

	GV_MIX_
};

#endif	// GVMIX_H__
