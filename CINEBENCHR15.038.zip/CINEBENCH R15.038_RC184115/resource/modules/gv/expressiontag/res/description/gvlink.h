#ifndef GVLINK_H__
#define GVLINK_H__

enum
{

	GV_LINK_LIST = 1000,

	GV_LINK_OPERATOR_INDEX = 2000,

	GV_LINK_OUTPUT = 3000,
	GV_LINK_OUTPUT_COUNT,

	GV_LINK_
};

#endif	// GVLINK_H__
