#ifndef GVCOMMENT_H__
#define GVCOMMENT_H__

enum
{
	GV_COMMENT_STRING		= 1000,

	GV_COMMENT_
};

#endif	// GVCOMMENT_H__
