#ifndef GVNOT_H__
#define GVNOT_H__

#include "gvbase.h"

enum
{
	GV_NOT_INPUT								= 2000,
	GV_NOT_OUTPUT								= 3000,

	GV_NOT_
};

#endif	// GVNOT_H__
