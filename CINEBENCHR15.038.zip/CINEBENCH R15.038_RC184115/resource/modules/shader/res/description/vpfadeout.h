#ifndef VPFADEOUT_H__
#define VPFADEOUT_H__

enum
{
	VPFADEOUT_TRANSPARENCY							= 1000,				// Real
	VPFADEOUT_FILENAME									= 1001,				// Filename
};

#endif	// VPFADEOUT_H__
