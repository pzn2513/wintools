#ifndef CKDATA_H__
#define CKDATA_H__

#endif	// CKDATA_H__
