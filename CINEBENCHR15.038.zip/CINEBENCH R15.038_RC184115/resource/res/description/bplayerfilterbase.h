#ifndef BPLAYERFILTERBASE_H__
#define BPLAYERFILTERBASE_H__

#include "bplayer.h"

enum
{
	// object properties
	ID_PAINTLAYERFILTER_			= 3000,
	ID_PAINTLAYERFILTER_END
};

#endif	// BPLAYERFILTERBASE_H__
