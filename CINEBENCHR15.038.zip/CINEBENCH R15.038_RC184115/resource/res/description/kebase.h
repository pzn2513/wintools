#ifndef KEBASE_H__
#define KEBASE_H__

enum
{
	ID_KEYPROPERTIES			= 807,
	ID_BASEKEY_NAME				= 900,
	ID_BASEKEY_TIME 			= 901
};

#endif	// KEBASE_H__
