#ifndef KEPLA_H__
#define KEPLA_H__

enum
{
	PLA_BIAS	= 10002, // real
	PLA_CUBIC	= 10003, // bool

	PLA_DUMMY
};

#endif	// KEPLA_H__
