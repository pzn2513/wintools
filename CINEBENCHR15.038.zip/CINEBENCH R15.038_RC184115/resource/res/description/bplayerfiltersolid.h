#ifndef BPLAYERFILTERSOLID_H__
#define BPLAYERFILTERSOLID_H__

#include "bplayerfilterbase.h"

enum
{
	// object properties
	ID_PAINTLAYERFILTERSOLID_COLOR			= 4000,
	ID_PAINTLAYERFILTERSOLID_END
};

#endif	// BPLAYERFILTERSOLID_H__
