#ifndef MPREVIEW_H__
#define MPREVIEW_H__

enum
{
	ID_MATERIAL_PREVIEW = 831,
	MATERIAL_PREVIEW	= 520000000
};

#endif	// MPREVIEW_H__
