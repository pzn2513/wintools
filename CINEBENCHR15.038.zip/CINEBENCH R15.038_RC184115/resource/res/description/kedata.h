#ifndef KEDATA_H__
#define KEDATA_H__

#include "kebase.h"

enum
{
	EX_DATAKEY_VALUE	= 1000
};

#endif	// KEDATA_H__
