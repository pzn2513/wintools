#ifndef BPSPLINELINE_H__
#define BPSPLINELINE_H__

#include "bpspline.h"

enum
{
	// object properties
	ID_PAINTSPLINELINE_						= 2000,

	ID_PAINTSPLINELINE_END
};

#endif	// BPSPLINELINE_H__
