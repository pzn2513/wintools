#ifndef BPSPLINEGROUP_H__
#define BPSPLINEGROUP_H__

#include "bpspline.h"

enum
{
	// object properties
	ID_PAINTSPLINEGROUP_						= 2000,

	ID_PAINTSPLINEGROUP_END
};

#endif	// BPSPLINEGROUP_H__
