#ifndef BPLAYERFOLDER_H__
#define BPLAYERFOLDER_H__

#include "bplayer.h"

enum
{
	// object properties
	ID_PAINTLAYERFOLDER_			= 3000,
	ID_PAINTLAYERFOLDER_END
};

#endif	// BPLAYERFOLDER_H__
