#ifndef FBASE_H__
#define FBASE_H__

enum
{
	ID_FILTERPROPERTIES		= 1001023
};

#endif	// FBASE_H__
