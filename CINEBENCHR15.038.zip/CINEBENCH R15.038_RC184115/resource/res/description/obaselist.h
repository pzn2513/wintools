#ifndef OBASELIST_H__
#define OBASELIST_H__

enum
{
	ID_LAYER_LINK    = 898,
	ID_BASELIST_NAME = 900
};

#endif	// OBASELIST_H__
