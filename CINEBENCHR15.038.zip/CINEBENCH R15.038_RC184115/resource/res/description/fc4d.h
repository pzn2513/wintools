#ifndef FC4D_H__
#define FC4D_H__

enum
{
	C4DIMPORTFILTER_GROUP						= 999,
	C4DIMPORTFILTER_SCALE						= 2000,
	C4DIMPORTFILTER_HINT						= 3000
};

#endif	// FC4D_H__
