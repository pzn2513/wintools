#ifndef KESOUND_H__
#define KESOUND_H__

#include "kebase.h"

enum
{
	ID_SOUNDKEYPROPERTIES = 1000,
	ID_SOUNDKEY_VOLUME	  = 1001,
	ID_SOUNDKEY_BALANCE	  = 1002
};

#endif	// KESOUND_H__
