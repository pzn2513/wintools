#ifndef DMATRIX_H__
#define DMATRIX_H__

enum
{
	MATRIX_OFF		= 1000,
	MATRIX_V1			= 1001,
	MATRIX_V2			= 1002,
	MATRIX_V3			= 1003
};

#endif	// DMATRIX_H__
