#ifndef BPLAYERBMP_H__
#define BPLAYERBMP_H__

#include "bplayer.h"

enum
{
	// object properties
	ID_PAINTLAYERBMP_OFFSET_X			= 3000,
	ID_PAINTLAYERBMP_OFFSET_Y			= 3001,
	ID_PAINTLAYERBMP_MODE					= 3002,
	ID_PAINTLAYERBMP_END
};

#endif	// BPLAYERBMP_H__
