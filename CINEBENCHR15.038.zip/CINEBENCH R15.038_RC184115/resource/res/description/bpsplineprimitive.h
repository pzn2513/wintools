#ifndef BPSPLINEPRIMITIVE_H__
#define BPSPLINEPRIMITIVE_H__

#include "bpspline.h"

enum
{
	// object properties
	ID_PAINTSPLINEPRIMITIVE_						= 2000,

	ID_PAINTSPLINEPRIMITIVE_END
};

#endif	// BPSPLINEPRIMITIVE_H__
