#ifndef DVECTOR_H__
#define DVECTOR_H__

enum
{
	VECTOR_X		= 1000,
	VECTOR_Y		= 1001,
	VECTOR_Z		= 1002
};

#endif	// DVECTOR_H__
