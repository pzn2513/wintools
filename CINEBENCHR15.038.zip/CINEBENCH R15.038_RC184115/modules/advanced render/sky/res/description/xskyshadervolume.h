#ifndef XSKYSHADERVOLUME_H__
#define XSKYSHADERVOLUME_H__

enum
{
	XskyshaderVolume                          = 1000,

	SKY_VOL_MATERIAL_PAGE_PROPERTIES          = 2000,

	SKY_VOL_MATERIAL_SKY_OBJ                  = 3001, // link

	SKY_SHADER_COL_MAT_DUMMY_
};

#endif	// XSKYSHADERVOLUME_H__
