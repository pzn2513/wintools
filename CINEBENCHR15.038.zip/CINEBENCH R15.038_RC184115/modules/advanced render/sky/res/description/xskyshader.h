#ifndef XSKYSHADER_H__
#define XSKYSHADER_H__

enum
{
	Xskyshader                            = 1000,

	SKY_MATERIAL_PAGE_PROPERTIES          = 2000,
	SKY_MATERIAL_SKY_OBJ                  = 3001, // link

	SKY_SHADER_MAT_DUMMY_
};

#endif	// XSKYSHADER_H__
