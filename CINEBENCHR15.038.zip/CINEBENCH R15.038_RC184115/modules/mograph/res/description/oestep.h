#ifndef OESTEP_H__
#define OESTEP_H__

enum
{
	MGSTEPEFFECTOR_SPLINE = 1100,
	MGSTEPEFFECTOR_GAP		= 1101
};
#endif	// OESTEP_H__
