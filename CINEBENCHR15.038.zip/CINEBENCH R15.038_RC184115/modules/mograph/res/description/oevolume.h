#ifndef OEVOLUME_H__
#define OEVOLUME_H__

enum
{
	MGVOLUMEEFFECTOR_OBJECT						= 1100
};
#endif	// OEVOLUME_H__
