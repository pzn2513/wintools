#ifndef MGPARTICLE_H__
#define MGPARTICLE_H__

enum
{
	MG_PARTICLE_STRETCH = 1040,
	MG_PARTICLE_SCALE		= 1041
};
#endif	// MGPARTICLE_H__
