#ifndef MGOBJECT_H__
#define MGOBJECT_H__

enum
{
	MG_OBJECT_LINK	= 1015, //Object cloning object link
	MG_OBJECT_ALIGN = 1016	//Align to surface/spline/particle
};
#endif	// MGOBJECT_H__
