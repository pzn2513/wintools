<?php
namespace app\api\controller;
use think\Db;
class Server{
	// usermod -G 组名1[，组名2，……] 一个用户多个组
	// groups  可以显示用户所有的 组。 比如 groups  aa


	// 注册账号 修改密码 显示分组
	function adduser(){
		halt($_REQUEST);
		// if($_REQUEST[''])
		// -M不创建家目录
		exec("adduser -g {$_REQUEST['group']} {$_REQUEST['user']}")
		
	}
}