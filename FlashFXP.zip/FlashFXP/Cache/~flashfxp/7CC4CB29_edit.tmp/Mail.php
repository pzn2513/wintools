<?php
namespace app\api\controller;
use think\Db;
class Mail
{
	function __construct(){
		define('API_USER','talenseed');
		define('API_KEY','E9CPtoZxwiQlVbQk');
	}

  function setTemplate(){
    db("mail_template")->insert(['name'=>$_REQUEST['name'],'text'=>$_REQUEST['text']]);
  }
  function showTemplate(){
    echo db("mail_template")->where('id',$_REQUEST['id'])->find()['text'];
  }
  function test(){
    return db('mailhook2')->where('event','request')->delete();
  }

  function receive(){
    $str=json_encode($_POST,JSON_UNESCAPED_UNICODE); 
    if(empty($str)){
      $str=json_encode($_GET);
      exec('echo get >> /home/wwwroot/www.talenmall.com/public/email/test');
    }
    exec('echo post >> /home/wwwroot/www.talenmall.com/public/email/test');
    $str=preg_replace('/\\\/','\\\\\\',$str);//方案1：这样替换后插入数据库能保存为最原始的string。
    // 主要应对情况为数组对象中有 json字符串 ，方案2：将该json字符串先解码。
    $sql="insert into mailhook (content)values('{$str}')";
    // echo $sql;
    return Db::execute($sql);
  }

  function showhook(){
// emailIds  message  timestamp
    $d=db('mailhook')->field('content')->select();
    for ($i=0; $i < count($d); $i++) {
      $str=$d[$i]['content'];
      // $str=preg_replace('/\["/','[',$str);
      // $str=preg_replace('/"\]/',']',$str);
      $arr=json_decode($str,true);
      // halt($arr);
      $r[]=$arr;
      // $r[]=['emailId'=>$arr['emailIds'],'message'=>$arr['message'],'event'=>$arr['event'],'time'=>date('Y-m-d H:i:s',$arr['timestamp'])];
    }
    return $r;
  }

  function setmaildate($time){
    $t=strtotime(date('Y-m-d',$time));
    if(db('maildate')->where('time='.$t)->find()){
      return $t;
    }
    return db('maildate')->insert(['time'=>$t]);
  }

  function showmaildate(){
    return db('maildate')->select();
  }

  function showhook2(){
    if(empty($_REQUEST['time'])){
      // $_REQUEST['time']=0;
      $timestr='timestamp1>0';
    }else{
      $timestr="timestamp1>{$_REQUEST['time']} and timestamp1<".($_REQUEST['time']+24*3600);
    }
    $sql="select event,count(*) from mailhook2 where {$timestr} group by event";   
    $count=Db::query($sql);
    // halt($count);
    if($_REQUEST['event']=='all'){
      $d=db('mailhook2')->where($timestr)->order('id desc')->limit(($_REQUEST['page']-1)*$_REQUEST['num'],$_REQUEST['num'])->select();
    }else{
      $d=db('mailhook2')->where($timestr)->where('event',$_REQUEST['event'])->order('id desc')->limit(($_REQUEST['page']-1)*$_REQUEST['num'],$_REQUEST['num'])->select();
    }
    $all=0;
    for ($i=0; $i < count($count); $i++) { 
      $d[$count[$i]['event']]=$count[$i]["count(*)"];
      $all+=$count[$i]["count(*)"];
    }
    $d['all']=$all;
    // halt($d);
    return $d;
  }
  function senderList(){
    return db('user')->field('id,nickname')->select();
  }
	// function input(){
	// 	$data=json_decode($_REQUEST['data'],true);
	// 	$phone=['18680372503','18011743686'];
	// 	$email=['pznforwork@outlook.com','dlcat@live.cn'];
	// 	for ($i=0; $i < count($data); $i++) { 
	// 		$n=rand(0,1);
	// 		Db::execute("insert into client set code='{$data[$i]['我方案号']}',number='{$data[$i]['专利号']}',name='{$data[$i]['发明名称']}',phone='{$phone[$n]}',email='{$email[$n]}'");
	// 	}		
	// }
	private function table($arr){
		if(!empty($arr)){	
			$str='<table border="1" rules="all" cellpadding="4" style="min-width:1000px">';
			foreach ($arr as $key => $value) {
				$str.='<tr>';
				foreach ($value as $k => $v) {
					$str.='<td align="center">'.$v.'</td>';
				}
				$str.='</tr>';
			}
			$str.='</table>';
			return $str;
		}
	}
  private function annualfee($appdate,$issdate,$no){
    $stamp=strtotime($appdate)+45*3600*24;
    $t1=explode('-',$appdate);  
    $t2=explode('-',$issdate);
    if(count($no)<12){
      $t=$no[2];
    }else{
      $t=$no[4];
    }
    if($t==='1'){
      // 2012/2/29
      // 2015/2/28
      // 2016/2/29
      if($t1[1]>$t2[1]){
        $year=$t2[0]-$t1[0];
      }else if($t1[1]==$t2[1]){
        if($t1[2]>$t2[2]){

        }else{

        }
        if($t1[1]==2){
          if($t1[2]==29){
            if($t2[2]==28||$t2[2]==29){

            }
          }
        }
        
      }else{
        $year=$t2[0]-$t1[0]+1;
      }
      // 3 900
      // 6 1200
      // 9 2000
      // 12 4000
      // 15 6000
      // 20 8000
    }else{
      // 3 600
      // 5 900
      // 8 1200
      // 10 2000
    }
    
  } 
	private function attachment($param,$arr){
    $mime_boundary=md5(time());
    // 配置参数
    $eol = "\r\n";
    $data = '';
    // halt($param);
    foreach ( $param as $key => $value ) { 
        $data .= '--' . $mime_boundary . $eol;  
        $data .= 'Content-Disposition: form-data; '; 
        $data .= "name=" . $key . $eol . $eol; 
        $data .= $value . $eol; 
    }
    // 配置文件   
		for ($i=0; $i < count($arr); $i++) {
      // halt($arr[$i]);
			$handle = fopen($arr[$i],'rb');
			$content = fread($handle,filesize($arr[$i]));
			$eol = "\r\n";
			$data .= '--' . $mime_boundary . $eol;
      preg_match('/(?<=\/)[^\/]+?$/',$arr[$i],$r);
      $data .= 'Content-Disposition: form-data; name="attachments"; filename="'.$r[0].'"' . $eol;
      $data .= 'Content-Type: text/plain' . $eol;
      $data .= 'Content-Transfer-Encoding: binary' . $eol . $eol;
      $data .= $content . $eol;
      fclose($handle);
		}
    $data.= "--" . $mime_boundary . "--" . $eol . $eol;
    $options = array(
            'http' => array(
                'method' => 'POST',
                'header' => 'Content-Type: multipart/form-data;boundary='.$mime_boundary . $eol,
                'content' => $data
        ));
    $context  = stream_context_create($options);
    return $context;
	}
// 授权
	function p1(){
    $d=json_decode($_REQUEST['data'],true);
    $dir=$_REQUEST['dir'];
    $url = 'http://api.sendcloud.net/apiv2/mail/send'; 
    $time=time();
    for ($i=0; $i < count($d); $i++) {   
      if(empty($client[$d[$i]['申请人']])){
        $client[$d[$i]['申请人']]=[$d[$i]];
      }else{
        array_push($client[$d[$i]['申请人']],$d[$i]);
      }
    }
    // halt($client);
    foreach ($client as $key => $value) {
      $total=0;
      $output='';
      $html=$this->p1text();
      $arr=[
        [
            '案号','申请人','专利名称','申请日','专利号','发文日','登记费','印花税','年度','年费','代理费','合计'
        ] 
      ];
      // dump($value);continue;
      for ($i=0; $i < count($value); $i++) {
        $total1=$value[$i]['登记费']+$value[$i]['印花税']+$value[$i]['年费']+$value[$i]['代理费'];
        array_push($arr,[$value[$i]['我方案号'],$value[$i]['申请人'],$value[$i]['专利名称'],$value[$i]['申请日'],$value[$i]['专利号'],$value[$i]['发文日'],$value[$i]['登记费'],$value[$i]['印花税'],$value[$i]['年度'],$value[$i]['年费'],$value[$i]['代理费'],$total1]);
        // 截止日期统一为通知时间后推40天
        $total+=$total1;
        // $issdate=;
        exec("find {$dir} -name '*{$value[$i]['我方案号']}*'",$output);
      }
      $table=$this->table($arr);
      $html=preg_replace("/%name%/",$value[0]['联系人称呼'],$html);
      $html=preg_replace("/%date%/",date(' Y 年 m 月 d 日 ',$time+40*3600*24),$html);
      $html=preg_replace("/%table%/",$table,$html);
      $html=preg_replace("/%total%/",$total,$html);
      $param = array(
          'apiUser' => API_USER, # 使用api_user和api_key进行验证
          'apiKey' => API_KEY,
          'from' => 'patent@email.talenseed.com', # 发信人，用正确邮件地址替代
          'fromName' => '专利缴费提醒',
          'to' => $value[0]['收件人邮箱'], # 收件人地址，用正确邮件地址替代，多个地址用';'分隔
          'subject' => '【授权缴费提醒】'.$key,
          'html' => $html,
          'respEmailId' => 'true',
          'cc'=>$value[0]['抄送人邮箱']
          // 'cc'=>'pznforwork@outlook.com;445892801@qq.com'
      );
      $context=$this->attachment($param,$output);
      $result[$key] = file_get_contents($url, FILE_TEXT, $context);
      $emaillist=json_decode($result[$key],true)['info']['emailIdList'];
      for ($i=0; $i < count($emaillist); $i++) { 
        Db::execute("insert mailhook2 (emailId,pid,event,message,timestamp1,type)values('{$emaillist[$i]}','".$_REQUEST['id']."','request','请求中','{$time}','{$key}.授权缴费提醒')");
      }
    }
    // halt($vars);
    // $table=$this->table($arr);
    $this->setmaildate($time);
    return $result;
	}

// 年费
  function p2(){
    $d=json_decode($_REQUEST['data'],true);
    $dir=$_REQUEST['dir'];
    $url = 'http://api.sendcloud.net/apiv2/mail/send'; 
    $time=time();

    for ($i=0; $i < count($d); $i++) {   
      if(empty($client[$d[$i]['申请人']])){
        $client[$d[$i]['申请人']]=[$d[$i]];
      }else{
        array_push($client[$d[$i]['申请人']],$d[$i]);
      }
    }
    foreach ($client as $key => $value) {
      $total=0;
      $output='';
      $html=$this->p2text();
      $arr=[
        [
            '案号','申请人','专利名称','申请日','专利号','年度','年费','代理费','放弃请在此确认（签名或盖章）'
        ] 
      ];
      for ($i=0; $i < count($value); $i++) {
        $total1=$value[$i]['年费']+$value[$i]['代理费'];
        array_push($arr,[$value[$i]['我方案号'],$value[$i]['申请人'],$value[$i]['专利名称'],$value[$i]['申请日'],$value[$i]['专利号'],$value[$i]['年度'],$value[$i]['年费'],$value[$i]['代理费'],null]);
        $total+=$total1;
      }
      $table=$this->table($arr);
      $html=preg_replace("/%name%/",$value[0]['联系人称呼'],$html);
      $html=preg_replace("/%date%/",date(' Y 年 m 月 d 日 ',$time+40*3600*24),$html);
      $html=preg_replace("/%table%/",$table,$html);
      $html=preg_replace("/%total%/",$total,$html);
      $param = array(
          'apiUser' => API_USER, # 使用api_user和api_key进行验证
          'apiKey' => API_KEY,
          'from' => 'patent@email.talenseed.com', # 发信人，用正确邮件地址替代
          'fromName' => '专利缴费提醒',
          'to' => $value[0]['收件人邮箱'], # 收件人地址，用正确邮件地址替代，多个地址用';'分隔
          'subject' => '【年费缴纳提醒】'.$key,
          'html' => $html,
          'respEmailId' => 'true',
          'cc'=>$value[0]['抄送人邮箱'],
      );
      $context=$this->attachment($param,[]);
      $result[$key] = file_get_contents($url, FILE_TEXT, $context);
      $emaillist=json_decode($result[$key],true)['info']['emailIdList'];
      for ($i=0; $i < count($emaillist); $i++) { 
        Db::execute("insert mailhook2 (emailId,pid,event,message,timestamp1,type)values('{$emaillist[$i]}','".$_REQUEST['id']."','request','请求中','{$time}','{$key}.年费缴纳提醒')");
      }
    }
    $this->setmaildate($time);
    return $result;
  }

// 滞纳金
  function p3(){
    // 滞纳金，日期开放出去修改
    $d=json_decode($_REQUEST['data'],true);
    $dir=$_REQUEST['dir'];
    $url = 'http://api.sendcloud.net/apiv2/mail/send'; 
    $time=time();
    for ($i=0; $i < count($d); $i++) {   
      if(empty($client[$d[$i]['申请人']])){
        $client[$d[$i]['申请人']]=[$d[$i]];
      }else{
        array_push($client[$d[$i]['申请人']],$d[$i]);
      }
    }
    foreach ($client as $key => $value) {
      $total=0;
      $output='';
      $html=$this->p3text();
      $arr=[
        [
            '案号','申请人','专利名称','申请日','专利号','年度','年费','滞纳金','代理费','放弃请在此确认（签名或盖章）'
        ] 
      ];
      for ($i=0; $i < count($value); $i++) {
        $total1=$value[$i]['年费']+$value[$i]['滞纳金']+$value[$i]['代理费'];
        array_push($arr,[$value[$i]['我方案号'],$value[$i]['申请人'],$value[$i]['专利名称'],$value[$i]['申请日'],$value[$i]['专利号'],$value[$i]['年度'],$value[$i]['年费'],$value[$i]['滞纳金'],$value[$i]['代理费'],null]);
        $total+=$total1;
        exec("find {$dir} -name '*{$value[$i]['我方案号']}*'",$output);
      }
      $table=$this->table($arr);
      $html=preg_replace("/%name%/",$value[0]['联系人称呼'],$html);
      $html=preg_replace("/%date%/",$value[0]['最迟回复日'],$html);
      $html=preg_replace("/%table%/",$table,$html);
      $html=preg_replace("/%total%/",$total,$html);
      $param = array(
          'apiUser' => API_USER, # 使用api_user和api_key进行验证
          'apiKey' => API_KEY,
          'from' => 'patent@email.talenseed.com', # 发信人，用正确邮件地址替代
          'fromName' => '专利缴费提醒',
          'to' => $value[0]['收件人邮箱'], # 收件人地址，用正确邮件地址替代，多个地址用';'分隔
          'subject' => '【年费滞纳金缴费提醒】'.$key,
          'html' => $html,
          'respEmailId' => 'true',
          'cc'=>$value[0]['抄送人邮箱']
      );
      $context=$this->attachment($param,$output);
      $result[$key] = file_get_contents($url, FILE_TEXT, $context);
      $emaillist=json_decode($result[$key],true)['info']['emailIdList'];
      for ($i=0; $i < count($emaillist); $i++) { 
        Db::execute("insert mailhook2 (emailId,pid,event,message,timestamp1,type)values('{$emaillist[$i]}','".$_REQUEST['id']."','request','请求中','{$time}','{$key}.年费滞纳金缴费提醒')");
      }
    }
    $this->setmaildate($time);
    return $result;
  }

// 滞纳金（放弃）
  function p4(){
    $d=json_decode($_REQUEST['data'],true);
    $dir=$_REQUEST['dir'];
    $url = 'http://api.sendcloud.net/apiv2/mail/send'; 
    $time=time();
    for ($i=0; $i < count($d); $i++) {   
      if(empty($client[$d[$i]['申请人']])){
        $client[$d[$i]['申请人']]=[$d[$i]];
      }else{
        array_push($client[$d[$i]['申请人']],$d[$i]);
      }
    }
    foreach ($client as $key => $value) {
      $total=0;
      $output='';
      $html=$this->p4text();
      $arr=[
        [
            '案号','申请人','专利名称','申请日','专利号'
        ] 
      ];
      for ($i=0; $i < count($value); $i++) {
        array_push($arr,[$value[$i]['我方案号'],$value[$i]['申请人'],$value[$i]['专利名称'],$value[$i]['申请日'],$value[$i]['专利号']]);
        exec("find {$dir} -name '*{$value[$i]['我方案号']}*'",$output);
      }
      $table=$this->table($arr);
      $html=preg_replace("/%name%/",$value[0]['联系人称呼'],$html);
      // $html=preg_replace("/%date%/",date(' Y 年 m 月 d 日 ',time()+40*3600*24),$html);
      $html=preg_replace("/%table%/",$table,$html);
      $param = array(
          'apiUser' => API_USER, # 使用api_user和api_key进行验证
          'apiKey' => API_KEY,
          'from' => 'patent@email.talenseed.com', # 发信人，用正确邮件地址替代
          'fromName' => '专利缴费提醒',
          'to' => $value[0]['收件人邮箱'], # 收件人地址，用正确邮件地址替代，多个地址用';'分隔
          'subject' => '【年费滞纳金缴费提醒（客户放弃）】'.$key,
          'html' => $html,
          'respEmailId' => 'true',
          'cc'=>$value[0]['抄送人邮箱']
      );
      $context=$this->attachment($param,$output);
      $result[$key] = file_get_contents($url, FILE_TEXT, $context);
      $emaillist=json_decode($result[$key],true)['info']['emailIdList'];
      for ($i=0; $i < count($emaillist); $i++) { 
        Db::execute("insert mailhook2 (emailId,pid,event,message,timestamp1,type)values('{$emaillist[$i]}','".$_REQUEST['id']."','request','请求中','{$time}','{$key}.年费滞纳金缴费提醒（客户放弃）')");
      }
    }
    $this->setmaildate($time);
    return $result;
  }

// 终止
  function p5(){
    $d=json_decode($_REQUEST['data'],true);
    $dir=$_REQUEST['dir'];
    $url = 'http://api.sendcloud.net/apiv2/mail/send'; 
    $time=time();
    for ($i=0; $i < count($d); $i++) {   
      if(empty($client[$d[$i]['申请人']])){
        $client[$d[$i]['申请人']]=[$d[$i]];
      }else{
        array_push($client[$d[$i]['申请人']],$d[$i]);
      }
    }
    foreach ($client as $key => $value) {
      $total=0;
      $output='';
      $html=$this->p5text();
      $arr=[
        [
            '案号','申请人','专利名称','申请日','专利号','年度','年费','滞纳金','代理费','官方恢复费','恢复代理费','合计'
        ] 
      ];
      for ($i=0; $i < count($value); $i++) {
        $total1=$value[$i]['年费']+$value[$i]['滞纳金']+$value[$i]['代理费']+$value[$i]['官方恢复费']+$value[$i]['恢复代理费'];
        array_push($arr,[$value[$i]['我方案号'],$value[$i]['申请人'],$value[$i]['专利名称'],$value[$i]['申请日'],$value[$i]['专利号'],$value[$i]['年度'],$value[$i]['年费'],$value[$i]['滞纳金'],$value[$i]['代理费'],$value[$i]['官方恢复费'],$value[$i]['恢复代理费'],$total1]);
        $total+=$total1;
        exec("find {$dir} -name '*{$value[$i]['我方案号']}*'",$output);
      }
      $table=$this->table($arr);
      $html=preg_replace("/%name%/",$value[0]['联系人称呼'],$html);
      // $html=preg_replace("/%date%/",date(' Y 年 m 月 d 日 ',time()+40*3600*24),$html);
      $html=preg_replace("/%table%/",$table,$html);
      $html=preg_replace("/%total%/",$total,$html);
      $param = array(
          'apiUser' => API_USER, # 使用api_user和api_key进行验证
          'apiKey' => API_KEY,
          'from' => 'patent@email.talenseed.com', # 发信人，用正确邮件地址替代
          'fromName' => '专利缴费提醒',
          'to' => $value[0]['收件人邮箱'], # 收件人地址，用正确邮件地址替代，多个地址用';'分隔
          'subject' => '【专利终止提醒】'.$key,
          'html' => $html,
          'respEmailId' => 'true',
          'cc'=>$value[0]['抄送人邮箱']
      );
      $context=$this->attachment($param,$output);
      $result[$key] = file_get_contents($url, FILE_TEXT, $context);
      $emaillist=json_decode($result[$key],true)['info']['emailIdList'];
      for ($i=0; $i < count($emaillist); $i++) { 
        Db::execute("insert mailhook2 (emailId,pid,event,message,timestamp1,type)values('{$emaillist[$i]}','".$_REQUEST['id']."','request','请求中','{$time}','{$key}.专利终止提醒')");
      }
    }
    $this->setmaildate($time);
    return $result;
  }

// 终止（届满）
  function p6(){
    $d=json_decode($_REQUEST['data'],true);
    $dir=$_REQUEST['dir'];
    $url = 'http://api.sendcloud.net/apiv2/mail/send'; 
    $time=time();
    for ($i=0; $i < count($d); $i++) {
      if(empty($client[$d[$i]['申请人']])){
        $client[$d[$i]['申请人']]=[$d[$i]];
      }else{
        array_push($client[$d[$i]['申请人']],$d[$i]);
      }
    }
    foreach ($client as $key => $value) {
      $total=0;
      $output='';
      $html=$this->p6text();
      $arr=[
        [
            '案号','申请人','专利名称','申请日','专利号','发文日'
        ] 
      ];
      for ($i=0; $i < count($value); $i++) {
        array_push($arr,[$value[$i]['我方案号'],$value[$i]['申请人'],$value[$i]['专利名称'],$value[$i]['申请日'],$value[$i]['专利号'],$value[$i]['发文日']]);
        exec("find {$dir} -name '*{$value[$i]['我方案号']}*'",$output);
      }
      $table=$this->table($arr);
      $html=preg_replace("/%name%/",$value[0]['联系人称呼'],$html);
      // $html=preg_replace("/%date%/",date(' Y 年 m 月 d 日 ',time()+40*3600*24),$html);
      $html=preg_replace("/%table%/",$table,$html);
      $param = array(
          'apiUser' => API_USER, # 使用api_user和api_key进行验证
          'apiKey' => API_KEY,
          'from' => 'patent@email.talenseed.com', # 发信人，用正确邮件地址替代
          'fromName' => '专利缴费提醒',
          'to' => $value[0]['收件人邮箱'], # 收件人地址，用正确邮件地址替代，多个地址用';'分隔
          'subject' => '【专利终止提醒（届满）】'.$key,
          'html' => $html,
          'respEmailId' => 'true',
          'cc'=>$value[0]['抄送人邮箱']
      );
      $context=$this->attachment($param,$output);
      $result[$key] = file_get_contents($url, FILE_TEXT, $context);
      $emaillist=json_decode($result[$key],true)['info']['emailIdList'];
      for ($i=0; $i < count($emaillist); $i++) { 
        Db::execute("insert mailhook2 (emailId,pid,event,message,timestamp1,type)values('{$emaillist[$i]}','".$_REQUEST['id']."','request','请求中','{$time}','{$key}.专利终止提醒（届满）')");
      }
    }
    $this->setmaildate($time);
    return $result;
  }

// 终止（客户放弃）
  function p7(){
    $d=json_decode($_REQUEST['data'],true);
    $dir=$_REQUEST['dir'];
    $url = 'http://api.sendcloud.net/apiv2/mail/send'; 
    $time=time();
    for ($i=0; $i < count($d); $i++) {
      if(empty($client[$d[$i]['申请人']])){
        $client[$d[$i]['申请人']]=[$d[$i]];
      }else{
        array_push($client[$d[$i]['申请人']],$d[$i]);
      }
    }
    foreach ($client as $key => $value) {
      $total=0;
      $output='';
      $html=$this->p7text();
      $arr=[
        [
            '案号','申请人','专利名称','申请日','专利号','发文日'
        ] 
      ];
      for ($i=0; $i < count($value); $i++) {
        array_push($arr,[$value[$i]['我方案号'],$value[$i]['申请人'],$value[$i]['专利名称'],$value[$i]['申请日'],$value[$i]['专利号'],$value[$i]['发文日']]);
        exec("find {$dir} -name '*{$value[$i]['我方案号']}*'",$output);
      }
      $table=$this->table($arr);
      $html=preg_replace("/%name%/",$value[0]['联系人称呼'],$html);
      // $html=preg_replace("/%date%/",date(' Y 年 m 月 d 日 ',time()+40*3600*24),$html);
      $html=preg_replace("/%table%/",$table,$html);
      $param = array(
          'apiUser' => API_USER, # 使用api_user和api_key进行验证
          'apiKey' => API_KEY,
          'from' => 'patent@email.talenseed.com', # 发信人，用正确邮件地址替代
          'fromName' => '专利缴费提醒',
          'to' => $value[0]['收件人邮箱'], # 收件人地址，用正确邮件地址替代，多个地址用';'分隔
          'subject' => '【专利终止提醒（客户放弃）】'.$key,
          'html' => $html,
          'respEmailId' => 'true',
          'cc'=>$value[0]['抄送人邮箱']
      );
      $context=$this->attachment($param,$output);
      $result[$key] = file_get_contents($url, FILE_TEXT, $context);
      $emaillist=json_decode($result[$key],true)['info']['emailIdList'];
      for ($i=0; $i < count($emaillist); $i++) { 
        Db::execute("insert mailhook2 (emailId,pid,event,message,timestamp1,type)values('{$emaillist[$i]}','".$_REQUEST['id']."','request','请求中','{$time}','{$key}.专利终止提醒（客户放弃）')");
      }
    }
    $this->setmaildate($time);
    return $result;
  }

// 视弃
  function p8(){
    $d=json_decode($_REQUEST['data'],true);
    $dir=$_REQUEST['dir'];
    $url = 'http://api.sendcloud.net/apiv2/mail/send'; 
    $time=time();
    for ($i=0; $i < count($d); $i++) {   
      if(empty($client[$d[$i]['申请人']])){
        $client[$d[$i]['申请人']]=[$d[$i]];
      }else{
        array_push($client[$d[$i]['申请人']],$d[$i]);
      }
    }
    foreach ($client as $key => $value) {
      $output='';
      $html=$this->p8text();
      $arr=[
        [
            '案号','申请人','专利名称','申请日','专利号','发文日'
        ] 
      ];
      for ($i=0; $i < count($value); $i++) {
        array_push($arr,[$value[$i]['我方案号'],$value[$i]['申请人'],$value[$i]['专利名称'],$value[$i]['申请日'],$value[$i]['专利号'],$value[$i]['发文日']]);
        exec("find {$dir} -name '*{$value[$i]['我方案号']}*'",$output);
      }
      $table=$this->table($arr);
      $html=preg_replace("/%name%/",$value[0]['联系人称呼'],$html);
      $html=preg_replace("/%table%/",$table,$html);
      $param = array(
          'apiUser' => API_USER, # 使用api_user和api_key进行验证
          'apiKey' => API_KEY,
          'from' => 'patent@email.talenseed.com', # 发信人，用正确邮件地址替代
          'fromName' => '专利缴费提醒',
          'to' => $value[0]['收件人邮箱'], # 收件人地址，用正确邮件地址替代，多个地址用';'分隔
          'subject' => '【视为放弃取得专利权提醒】'.$key,
          'html' => $html,
          'respEmailId' => 'true',
          'cc'=>$value[0]['抄送人邮箱']
      );
      $context=$this->attachment($param,$output);
      $result[$key] = file_get_contents($url, FILE_TEXT, $context);
      $emaillist=json_decode($result[$key],true)['info']['emailIdList'];
      for ($i=0; $i < count($emaillist); $i++) { 
        Db::execute("insert mailhook2 (emailId,pid,event,message,timestamp1,type)values('{$emaillist[$i]}','".$_REQUEST['id']."','request','请求中','{$time}','{$key}.视为放弃取得专利权提醒')");
      }
    }
    $this->setmaildate();
    return $result;
  }
  private function p1text(){
    return '<meta charset="UTF-8">
<title></title>
<style type="text/css">body{
            margin-bottom: 50px;
            font-family: "宋体";
        }
        .authorisedPayment{
            width:1200px;
            margin:0 auto;
        }
        .indent{
            text-indent: 2em;
            display: block;
            margin-top: 10px;
        }
        .blue{
            color: #0000ff;
        }
        .table{
            margin-top:28px;
        }
        .bold td{
            font-weight: bold;
        }
        td{
            height:30px;
            text-align: center;
            background: white;
        }
        .tip{
            font-size: 14px;
            margin-left: 30px;
        }
        .tipWord{
            line-height: 21px;
        }
        .contact{
          font-size: 16px;
            line-height: 35px;
        }
        .address{
           color: #000066;
        }
        .addressChin{
            font-size: 14px;
            line-height: 20px;
        }
       .addressEng{
           font-size: 12px;
       }
        .person{
            color: #223278;
            font-weight: bold;
            font-size: 14px;
            line-height: 20px;
        }
        .eval{
            letter-spacing: 1px;
        }
</style>
<div class="authorisedPayment">
<p>尊敬的%name%，您好：<br />
<span class="indent">下表所列专利应当缴纳相关费用。</span> <span class="indent">如专利权人愿意保持专利权继续有效，请于<span class="blue">%date%</span>之前通知我公司，联系确认相关事宜，以免专利失效。</span> <span class="indent">如在期限届满前未收到相关费用或贵方的相应指示，我公司将不会向中国专利局缴纳相关费用。</span></p>

<p><span class="indent">%table%</span></p>
<br><br>

<div class="table">
<p style="display: flex;justify-content: flex-end;margin-right: 150px;font-weight: bold"><span>总计（元）：%total%</span></p>
</div>

<div class="tip">
<p class="tipWord">【提示】<br />
1. 如贵方委托我公司代为缴纳本次年费，烦请将相应款项汇至我公司账户，并将汇款凭证发至我公司，以便我公司及时查账；<br />
2. 汇款时请以申请人的名义汇款，如果汇款人与申请人不一致时，务必写明正确的专利号。<br />
3. 有关缴费收据：<br />
&nbsp;&nbsp;&nbsp;3.1 专利局缴费收据上的缴费人信息，如贵方已有总指示，我公司将依照执行；<br />
&nbsp;&nbsp;&nbsp;3.2 如您对缴费人信息有特殊要求，请明确指示；<br />
&nbsp;&nbsp;&nbsp;3.3 如您对缴费人信息没有特殊要求，将依照我公司财务规定执行。<br />
4. 如贵方联系方式有变动，请及时告知并与我公司确认新的联系方式，以免造成沟通不便，导致产生额外费用或造成专利失效。<br />
<br />
感谢贵方一直以来对于我公司工作的支持与信任。<br />
烦请回函确收本邮件，谢谢！<br />
如有任何问题，请随时联系。</p>
<br />
<span>******************************************</span>

<p class="contact">户 名：北京集佳知识产权代理有限公司广州分公司<br />
账 号：11013548368101<br />
开户地：广东省广州市<br />
开户行：平安银行广州分行（或平安银行广州财富广场支行）</p>

<p class="person">年费组-梁嘉玲<br />
广东集之家律师事务所<br />
北京集佳知识产权代理有限公司广州分公司<br />
UNITALEN ATTORNEYS AT LAW GUANGZHOU BRANCH</p>

<div class="address">
<p class="addressChin">广州市天河区珠江东路30号广州银行大厦52层（510620）<br />
年费组咨询电话：8620-38813588 - 829<br />
传真：8620-38806446 - 713<br />
邮箱：<span class="blue">gzlc4@chinajijia.com</span><br />
客户服务监督热线：400 880 2939<br />
<span class="blue">http://www.unitalen.com</span></p>
<span class="eval">====================================================================================================================================================</span><br />
<br />
<span class="addressEng">本邮件载有秘密信息，请您恪守保密义务，勿向第三人透漏。谢谢合作。</span>

<p>&nbsp;</p>
<span class="addressEng"> This message contains information which may be confidential and privileged. Unless you are the addressee (or authorized to receive for the addressee), you may<br />
not use, copy or disclose to anyone the message or any information contained in the message. </span></div>
</div>
</div>
';
  }
  private function p2text(){
    return '<meta charset="UTF-8">
<title></title>
<style type="text/css">body{
            margin-bottom: 50px;
            font-family: "宋体";
        }
        .authorisedPayment{
            width:1200px;
            margin:0 auto;
        }
        .indent{
            text-indent: 2em;
            display: block;
            margin-top: 10px;
        }
        .blue{
            color: #0000ff;
        }
        .table{
            margin-top:28px;
        }
        .bold td{
            font-weight: bold;
        }
        td{
            height:30px;
            text-align: center;
            background: white;
        }
        .tip{
            font-size: 14px;
            margin-left: 30px;
        }
        .tipWord{
            line-height: 21px;
        }
        .contact{
            font-size: 16px;
            line-height: 35px;
        }
        .address{
            color: #000066;
        }
        .addressChin{
            font-size: 14px;
            line-height: 20px;
        }
        .addressEng{
            font-size: 12px;
        }
        .person{
            color: #223278;
            font-weight: bold;
            font-size: 14px;
            line-height: 20px;
        }
        .eval{
            letter-spacing: 1px;
        }
</style>
<div class="authorisedPayment">
<p>尊敬的%name%，您好：<br />
<span class="indent">下表所列专利应当缴纳相关费用。</span> <span class="indent">如专利权人愿意保持专利权继续有效，请于<span class="blue">%date%</span>之前通知我公司，联系确认相关事宜，以免专利失效。</span> <span class="indent">如在期限届满前未收到相关费用或贵方的相应指示，我公司将不会向中国专利局缴纳相关费用。</span></p>

<p><span class="indent">%table%</span></p>
<br><br>

<div class="table">
<p style="display: flex;justify-content: flex-end;margin-right: 150px;font-weight: bold"><span>总计（元）：%total%</span></p>
</div>

<div class="tip">
<p class="tipWord">【提示】<br />
1. 如贵方委托我公司代为缴纳本次年费，烦请将相应款项汇至我公司账户，并将汇款凭证发至我公司，以便我公司及时查账；<br />
2. 汇款时请以申请人的名义汇款，如果汇款人与申请人不一致时，务必写明正确的专利号。<br />
3. 有关缴费收据：<br />
&nbsp;&nbsp;&nbsp;3.1 专利局缴费收据上的缴费人信息，如贵方已有总指示，我公司将依照执行；<br />
&nbsp;&nbsp;&nbsp;3.2 如您对缴费人信息有特殊要求，请明确指示；<br />
&nbsp;&nbsp;&nbsp;3.3 如您对缴费人信息没有特殊要求，将依照我公司财务规定执行。<br />
4. 如贵方联系方式有变动，请及时告知并与我公司确认新的联系方式，以免造成沟通不便，导致产生额外费用或造成专利失效。<br />
<br />
感谢贵方一直以来对于我公司工作的支持与信任。<br />
烦请回函确收本邮件，谢谢！<br />
如有任何问题，请随时联系。</p>
<br />
<span>******************************************</span>

<p class="contact">户 名：北京集佳知识产权代理有限公司广州分公司<br />
账 号：11013548368101<br />
开户地：广东省广州市<br />
开户行：平安银行广州分行（或平安银行广州财富广场支行）</p>

<p class="person">年费组-梁嘉玲<br />
广东集之家律师事务所<br />
北京集佳知识产权代理有限公司广州分公司<br />
UNITALEN ATTORNEYS AT LAW GUANGZHOU BRANCH</p>

<div class="address">
<p class="addressChin">广州市天河区珠江东路30号广州银行大厦52层（510620）<br />
年费组咨询电话：8620-38813588 - 829<br />
传真：8620-38806446 - 713<br />
邮箱：<span class="blue">gzlc4@chinajijia.com</span><br />
客户服务监督热线：400 880 2939<br />
<span class="blue">http://www.unitalen.com</span></p>
<span class="eval">====================================================================================================================================================</span><br />
<br />
<span class="addressEng">本邮件载有秘密信息，请您恪守保密义务，勿向第三人透漏。谢谢合作。</span>

<p>&nbsp;</p>
<span class="addressEng"> This message contains information which may be confidential and privileged. Unless you are the addressee (or authorized to receive for the addressee), you may<br />
not use, copy or disclose to anyone the message or any information contained in the message. </span></div>
</div>
</div>
';
  }
  private function p3text(){
    return '<meta charset="UTF-8">
<title></title>
<style type="text/css">body{
            margin-bottom: 50px;
            font-family: "宋体";
        }
        .notice{
            color:red;
            font-size: 34px;
            margin-bottom: 13px;
            display: block;
        }
        .authorisedPayment{
            width:1200px;
            margin:0 auto;
        }
        .indent{
            text-indent: 2em;
            display: block;
            margin-top: 10px;
        }
        .blue{
            color: #0000ff;
        }
        .table{
            margin-top:28px;
        }
        .bold td{
            font-weight: bold;
        }
        td{
            height:30px;
            text-align: center;
            background: white;
        }
        .tip{
            font-size: 14px;
            margin-left: 30px;
        }
        .tipWord{
            line-height: 21px;
        }
        .contact{
            font-size: 16px;
            line-height: 35px;
        }
        .address{
            color: #000066;
        }
        .addressChin{
            font-size: 14px;
            line-height: 20px;
        }
        .addressEng{
            font-size: 12px;
        }
        .person{
            color: #223278;
            font-weight: bold;
            font-size: 14px;
            line-height: 20px;
        }
        .eval{
            letter-spacing: 1px;
        }
</style>
<div class="authorisedPayment">
<p><span class="notice">提醒!</span><br />
尊敬的%name%，您好：<br />
<span class="indent">下表所列专利应当缴纳相关费用。</span> <span class="indent">如专利权人愿意保持专利权继续有效，请于<span class="blue">%date%</span>之前通知我公司，联系确认相关事宜，以免专利失效。</span> <span class="indent">如在期限届满前未收到相关费用或贵方的相应指示，我公司将不会向中国专利局缴纳相关费用。</span></p>

<p><span class="indent">%table%</span></p>
<br><br>

<div class="table">
<p style="display: flex;justify-content: flex-end;margin-right: 150px;font-weight: bold"><span>总计（元）：%total%</span></p>
</div>

<div class="tip">
<p class="tipWord">【提示】<br />
1. 如贵方委托我公司代为缴纳本次年费，烦请将相应款项汇至我公司账户，并将汇款凭证发至我公司，以便我公司及时查账；<br />
2. 汇款时请以申请人的名义汇款，如果汇款人与申请人不一致时，务必写明正确的专利号。<br />
3. 有关缴费收据：<br />
&nbsp;&nbsp;&nbsp;3.1 专利局缴费收据上的缴费人信息，如贵方已有总指示，我公司将依照执行；<br />
&nbsp;&nbsp;&nbsp;3.2 如您对缴费人信息有特殊要求，请明确指示；<br />
&nbsp;&nbsp;&nbsp;3.3 如您对缴费人信息没有特殊要求，将依照我公司财务规定执行。<br />
4. 如贵方联系方式有变动，请及时告知并与我公司确认新的联系方式，以免造成沟通不便，导致产生额外费用或造成专利失效。<br />
<br />
感谢贵方一直以来对于我公司工作的支持与信任。<br />
烦请回函确收本邮件，谢谢！<br />
如有任何问题，请随时联系。</p>
<br />
<span>******************************************</span>

<p class="contact">户 名：北京集佳知识产权代理有限公司广州分公司<br />
账 号：11013548368101<br />
开户地：广东省广州市<br />
开户行：平安银行广州分行（或平安银行广州财富广场支行）</p>

<p class="person">年费组-梁嘉玲<br />
广东集之家律师事务所<br />
北京集佳知识产权代理有限公司广州分公司<br />
UNITALEN ATTORNEYS AT LAW GUANGZHOU BRANCH</p>

<div class="address">
<p class="addressChin">广州市天河区珠江东路30号广州银行大厦52层（510620）<br />
年费组咨询电话：8620-38813588 - 829<br />
传真：8620-38806446 - 713<br />
邮箱：<span class="blue">gzlc4@chinajijia.com</span><br />
客户服务监督热线：400 880 2939<br />
<span class="blue">http://www.unitalen.com</span></p>
<span class="eval">====================================================================================================================================================</span><br />
<br />
<span class="addressEng">本邮件载有秘密信息，请您恪守保密义务，勿向第三人透漏。谢谢合作。</span>

<p>&nbsp;</p>
<span class="addressEng"> This message contains information which may be confidential and privileged. Unless you are the addressee (or authorized to receive for the addressee), you may<br />
not use, copy or disclose to anyone the message or any information contained in the message. </span></div>
</div>
</div>
';
  }
  private function p4text(){
    return '<meta charset="UTF-8">
<title></title>
<style type="text/css">body{
            margin-bottom: 50px;
            font-family: "宋体";
        }
        .notice{
            color:red;
            font-size: 34px;
            margin-bottom: 13px;
            display: block;
        }
        .authorisedPayment{
            width:1200px;
            margin:0 auto;
        }
        .indent{
            text-indent: 2em;
            display: block;
            margin-top: 10px;
        }
        .blue{
            color: #0000ff;
        }
        .table{
            margin-top:28px;
        }
        .bold td{
            font-weight: bold;
        }
        td{
            height:30px;
            text-align: center;
            background: white;
        }
        .tip{
            font-size: 14px;
            margin-left: 30px;
        }
        .tipWord{
            line-height: 21px;
        }
        .contact{
            font-size: 16px;
            line-height: 35px;
        }
        .address{
            color: #000066;
        }
        .addressChin{
            font-size: 14px;
            line-height: 20px;
        }
        .addressEng{
            font-size: 12px;
        }
        .person{
            color: #223278;
            font-weight: bold;
            font-size: 14px;
            line-height: 20px;
        }
        .eval{
            letter-spacing: 1px;
        }
</style>
<div class="authorisedPayment">
<p><span class="notice">提醒!</span><br />
尊敬的%name%，您好：<br />
<span class="indent">附件为专利局下发的缴费通知书，请查阅。如有任何疑问请随时与我联系，谢谢！</span></p>

<p><span class="indent">%table%</span></p>
<br><br>

<p class="person">年费组-梁嘉玲<br />
广东集之家律师事务所<br />
北京集佳知识产权代理有限公司广州分公司<br />
UNITALEN ATTORNEYS AT LAW GUANGZHOU BRANCH</p>

<div class="address">
<p class="addressChin">广州市天河区珠江东路30号广州银行大厦52层（510620）<br />
年费组咨询电话：8620-38813588 - 829<br />
传真：8620-38806446 - 713<br />
邮箱：<span class="blue">gzlc4@chinajijia.com</span><br />
客户服务监督热线：400 880 2939<br />
<span class="blue">http://www.unitalen.com</span></p>
<span class="eval">====================================================================================================================================================</span><br />
<br />
<span class="addressEng">本邮件载有秘密信息，请您恪守保密义务，勿向第三人透漏。谢谢合作。</span>

<p>&nbsp;</p>
<span class="addressEng"> This message contains information which may be confidential and privileged. Unless you are the addressee (or authorized to receive for the addressee), you may<br />
not use, copy or disclose to anyone the message or any information contained in the message. </span></div>
</div>
</div>
';
  }
  private function p5text(){
    return '<meta charset="UTF-8">
<title></title>
<style type="text/css">body{
            margin-bottom: 50px;
            font-family: "宋体";
        }
        .notice{
            color:red;
            font-size: 34px;
            margin-bottom: 13px;
            display: block;
        }
        .authorisedPayment{
            width:1200px;
            margin:0 auto;
        }
        .indent{
            text-indent: 2em;
            display: block;
            margin-top: 10px;
        }
        .blue{
            color: #0000ff;
        }
        .table{
            margin-top:28px;
        }
        .bold td{
            font-weight: bold;
        }
        td{
            height:30px;
            text-align: center;
            background: white;
        }
        .tip{
            font-size: 14px;
            margin-left: 30px;
        }
        .tipWord{
            line-height: 21px;
        }
        .contact{
            font-size: 16px;
            line-height: 35px;
        }
        .address{
            color: #000066;
        }
        .addressChin{
            font-size: 14px;
            line-height: 20px;
        }
        .addressEng{
            font-size: 12px;
        }
        .person{
            color: #223278;
            font-weight: bold;
            font-size: 14px;
            line-height: 20px;
        }
        .eval{
            letter-spacing: 1px;
        }
</style>
<div class="authorisedPayment">
<p><span class="notice">提醒!</span><br />
尊敬的%name%，您好：<br />
<span class="indent">贵方专利，未在规定期限内缴纳下一年度年费。目前，收到官方下发的《专利权终止通知书》。</span><br>
  <span class="indent">如果贵方仍然希望维持该专利权有效，请务必于 发文日起一个月内 与我公司联系。</span><br> 
  <span class="indent">如在上述期限内，贵方没有任何回复，我方将视为贵方未委托我司办理题述专利的恢复事宜,由此产生的一切后果由贵司承担。</span><br>
  <span class="indent">随函附上专利局发出的《专利权终止通知书》。</span><br>
  <span class="indent">有问题请您联系我公司。
</span></p>

<p><span class="indent">%table%</span></p>
<br><br>

<div class="table">
<p style="display: flex;justify-content: flex-end;margin-right: 150px;font-weight: bold"><span>总计（元）：%total%</span></p>
</div>

<div class="tip">
<p class="tipWord">【提示】<br />
1. 如贵方委托我公司代为缴纳本次年费，烦请将相应款项汇至我公司账户，并将汇款凭证发至我公司，以便我公司及时查账；<br />
2. 汇款时请以申请人的名义汇款，如果汇款人与申请人不一致时，务必写明正确的专利号。<br />
3. 有关缴费收据：<br />
&nbsp;&nbsp;&nbsp;3.1 专利局缴费收据上的缴费人信息，如贵方已有总指示，我公司将依照执行；<br />
&nbsp;&nbsp;&nbsp;3.2 如您对缴费人信息有特殊要求，请明确指示；<br />
&nbsp;&nbsp;&nbsp;3.3 如您对缴费人信息没有特殊要求，将依照我公司财务规定执行。<br />
4. 如贵方联系方式有变动，请及时告知并与我公司确认新的联系方式，以免造成沟通不便，导致产生额外费用或造成专利失效。<br />
<br />
感谢贵方一直以来对于我公司工作的支持与信任。<br />
烦请回函确收本邮件，谢谢！<br />
如有任何问题，请随时联系。</p>
<br />
<span>******************************************</span>

<p class="contact">户 名：北京集佳知识产权代理有限公司广州分公司<br />
账 号：11013548368101<br />
开户地：广东省广州市<br />
开户行：平安银行广州分行（或平安银行广州财富广场支行）</p>

<p class="person">年费组-梁嘉玲<br />
广东集之家律师事务所<br />
北京集佳知识产权代理有限公司广州分公司<br />
UNITALEN ATTORNEYS AT LAW GUANGZHOU BRANCH</p>

<div class="address">
<p class="addressChin">广州市天河区珠江东路30号广州银行大厦52层（510620）<br />
年费组咨询电话：8620-38813588 - 829<br />
传真：8620-38806446 - 713<br />
邮箱：<span class="blue">gzlc4@chinajijia.com</span><br />
客户服务监督热线：400 880 2939<br />
<span class="blue">http://www.unitalen.com</span></p>
<span class="eval">====================================================================================================================================================</span><br />
<br />
<span class="addressEng">本邮件载有秘密信息，请您恪守保密义务，勿向第三人透漏。谢谢合作。</span>

<p>&nbsp;</p>
<span class="addressEng"> This message contains information which may be confidential and privileged. Unless you are the addressee (or authorized to receive for the addressee), you may<br />
not use, copy or disclose to anyone the message or any information contained in the message. </span></div>
</div>
</div>
';
  }
  private function p6text(){
    return '<meta charset="UTF-8">
<title></title>
<style type="text/css">body{
            margin-bottom: 50px;
            font-family: "宋体";
        }
        .notice{
            color:red;
            font-size: 34px;
            margin-bottom: 13px;
            display: block;
        }
        .authorisedPayment{
            width:1200px;
            margin:0 auto;
        }
        .indent{
            text-indent: 2em;
            display: block;
            margin-top: 10px;
        }
        .blue{
            color: #0000ff;
        }
        .table{
            margin-top:28px;
        }
        .bold td{
            font-weight: bold;
        }
        td{
            height:30px;
            text-align: center;
            background: white;
        }
        .tip{
            font-size: 14px;
            margin-left: 30px;
        }
        .tipWord{
            line-height: 21px;
        }
        .contact{
            font-size: 16px;
            line-height: 35px;
        }
        .address{
            color: #000066;
        }
        .addressChin{
            font-size: 14px;
            line-height: 20px;
        }
        .addressEng{
            font-size: 12px;
        }
        .person{
            color: #223278;
            font-weight: bold;
            font-size: 14px;
            line-height: 20px;
        }
        .eval{
            letter-spacing: 1px;
        }
</style>
<div class="authorisedPayment">
<p><span class="notice">提醒!</span><br />
尊敬的%name%，您好：<br />
<span class="indent">您好！附件为专利权终止通知书和官文，如有任何疑问，欢迎联系，谢谢！</span></p>

<p><span class="indent">%table%</span></p>
<br><br>

<p class="person">年费组-梁嘉玲<br />
广东集之家律师事务所<br />
北京集佳知识产权代理有限公司广州分公司<br />
UNITALEN ATTORNEYS AT LAW GUANGZHOU BRANCH</p>

<div class="address">
<p class="addressChin">广州市天河区珠江东路30号广州银行大厦52层（510620）<br />
年费组咨询电话：8620-38813588 - 829<br />
传真：8620-38806446 - 713<br />
邮箱：<span class="blue">gzlc4@chinajijia.com</span><br />
客户服务监督热线：400 880 2939<br />
<span class="blue">http://www.unitalen.com</span></p>
<span class="eval">====================================================================================================================================================</span><br />
<br />
<span class="addressEng">本邮件载有秘密信息，请您恪守保密义务，勿向第三人透漏。谢谢合作。</span>

<p>&nbsp;</p>
<span class="addressEng"> This message contains information which may be confidential and privileged. Unless you are the addressee (or authorized to receive for the addressee), you may<br />
not use, copy or disclose to anyone the message or any information contained in the message. </span></div>
</div>
</div>
';
  }
  private function p7text(){
    return '<meta charset="UTF-8">
<title></title>
<style type="text/css">body{
            margin-bottom: 50px;
            font-family: "宋体";
        }
        .notice{
            color:red;
            font-size: 34px;
            margin-bottom: 13px;
            display: block;
        }
        .authorisedPayment{
            width:1200px;
            margin:0 auto;
        }
        .indent{
            text-indent: 2em;
            display: block;
            margin-top: 10px;
        }
        .blue{
            color: #0000ff;
        }
        .table{
            margin-top:10px;
        }
        .bold td{
            font-weight: bold;
        }
        td{
            height:30px;
            text-align: center;
            background: white;
        }
        .tip{
            font-size: 14px;
            margin-left: 30px;
        }
        .tipWord{
            line-height: 21px;
        }
        .contact{
            font-size: 16px;
            line-height: 35px;
        }
        .address{
            color: #000066;
        }
        .addressChin{
            font-size: 14px;
            line-height: 20px;
        }
        .addressEng{
            font-size: 12px;
        }
        .person{
            color: #223278;
            font-weight: bold;
            font-size: 14px;
            line-height: 20px;
        }
        .eval{
            letter-spacing: 1px;
        }
</style>
<div class="authorisedPayment">
<p><span class="notice">提醒!</span><br />
尊敬的%name%：<br />
<span class="indent">贵方专利，未在规定期限内缴纳下一年度年费。目前，收到官方下发的《专利权终止通知书》。</span> <span class="indent">如果贵方仍然希望维持该专利权有效，请务必于发文日起一个月内 与我公司联系。</span> <span class="indent">如在上述期限内，贵方没有任何回复，我方将视为贵方未委托我司办理题述专利的恢复事宜,由此产生的一切后果由贵司承担。</span> <span class="indent">随函附上专利局发出的《专利权终止通知书》。</span> <span class="indent">有问题请您联系我公司。</span></p>

<p><span class="indent">%table%</span></p>
<br><br>

<div class="tip">
<p class="person">年费组-梁嘉玲<br />
广东集之家律师事务所<br />
北京集佳知识产权代理有限公司广州分公司<br />
UNITALEN ATTORNEYS AT LAW GUANGZHOU BRANCH</p>

<div class="address">
<p class="addressChin">广州市天河区珠江东路30号广州银行大厦52层（510620）<br />
年费组咨询电话：8620-38813588 - 829<br />
传真：8620-38806446 - 713<br />
邮箱：<span class="blue">gzlc4@chinajijia.com</span><br />
客户服务监督热线：400 880 2939<br />
<span class="blue">http://www.unitalen.com</span></p>
<span class="eval">====================================================================================================================================================</span><br />
<br />
<span class="addressEng">本邮件载有秘密信息，请您恪守保密义务，勿向第三人透漏。谢谢合作。</span>

<p>&nbsp;</p>
<span class="addressEng"> This message contains information which may be confidential and privileged. Unless you are the addressee (or authorized to receive for the addressee), you may not use, copy or disclose<br />
to anyone the message or any information contained in the message. </span></div>
</div>
</div>
';
  }
  private function p8text(){
    return '<meta charset="UTF-8">
<title></title>
<style type="text/css">body{
            margin-bottom: 50px;
            font-family: "宋体";
        }
        .notice{
            color:red;
            font-size: 34px;
            margin-bottom: 13px;
            display: block;
        }
        .authorisedPayment{
            width:1200px;
            margin:0 auto;
        }
        .indent{
            text-indent: 2em;
            display: block;
            margin-top: 10px;
        }
        .blue{
            color: #0000ff;
        }
        .table{
            margin-top:28px;
        }
        .bold td{
            font-weight: bold;
        }
        td{
            height:30px;
            text-align: center;
            background: white;
        }
        .tip{
            font-size: 14px;
            margin-left: 30px;
        }
        .tipWord{
            line-height: 21px;
        }
        .contact{
            font-size: 16px;
            line-height: 35px;
        }
        .address{
            color: #000066;
        }
        .addressChin{
            font-size: 14px;
            line-height: 20px;
        }
        .addressEng{
            font-size: 12px;
        }
        .person{
            color: #223278;
            font-weight: bold;
            font-size: 14px;
            line-height: 20px;
        }
        .eval{
            letter-spacing: 1px;
        }
</style>
<div class="authorisedPayment">
<p><span class="notice">提醒!</span><br />
尊敬的%name%：<br />
<span class="indent">贵方专利申请，未在规定期限内办理登记手续，不能授予专利权。目前，收到官方下发的《视为放弃取得专利权通知书》。</span> <span class="indent">如果贵方仍然希望获得该专利权，请务必于 发文日起期一个月内 与我公司联系。</span> <span class="indent">如在上述期限内，贵方没有任何回复，我方将视为贵方未委托我司办理题述专利的恢复事宜,由此产生的一切后果由贵司承担。</span> <span class="indent">随函附上专利局发出的《视为放弃取得专利权通知书》。</span> <span class="indent">有问题请您联系我公司。</span></p>

<p><span class="indent">%table%</span></p>
<br><br>

<div class="tip">
<p class="person">年费组-梁嘉玲<br />
广东集之家律师事务所<br />
北京集佳知识产权代理有限公司广州分公司<br />
UNITALEN ATTORNEYS AT LAW GUANGZHOU BRANCH</p>

<div class="address">
<p class="addressChin">广州市天河区珠江东路30号广州银行大厦52层（510620）<br />
年费组咨询电话：8620-38813588 - 829<br />
传真：8620-38806446 - 713<br />
邮箱：<span class="blue">gzlc4@chinajijia.com</span><br />
客户服务监督热线：400 880 2939<br />
<span class="blue">http://www.unitalen.com</span></p>
<span class="eval">====================================================================================================================================================</span><br />
<br />
<span class="addressEng">本邮件载有秘密信息，请您恪守保密义务，勿向第三人透漏。谢谢合作。</span>

<p>&nbsp;</p>
<span class="addressEng"> This message contains information which may be confidential and privileged. Unless you are the addressee (or authorized to receive for the addressee), you may not use, copy or disclose<br />
to anyone the message or any information contained in the message. </span></div>
</div>
</div>
';
  }
}