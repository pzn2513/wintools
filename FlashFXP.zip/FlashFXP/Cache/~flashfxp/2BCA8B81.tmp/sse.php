<?php
// 1.“Content-Type: text/event-stream”是专门为SSE设计的MIME类型`
// 2.retry可以定义推送间隔,如果不发送这个指令，默认间隔5000毫秒`
// 3.每行指令后面要有换行 \n ，用php的请用兼容方案 PHP_EOL`
// 4.最后一条指令要两个换行`
// 5.未完，其他详细容后发布`
    header('Content-Type: text/event-stream');
    // header('Cache-Control: no-cache');//不是必要
    $time = date('Y-m-d H:i:s');

    echo 'retry: 1000'.PHP_EOL;
    echo 'data: The server time is: '.$time.PHP_EOL.PHP_EOL;