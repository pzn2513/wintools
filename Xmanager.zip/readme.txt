During install use key:
180807-116568-999990
open keygen/NetSarang_AIO_7in1_Keygen_v1.1_DFoX_URET.exe and click "Fix Host + Register".